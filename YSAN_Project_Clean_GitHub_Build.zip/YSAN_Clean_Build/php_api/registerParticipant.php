<?php require 'db.php'; header('Content-Type: application/json');
try {
  $pdo->beginTransaction();
  $eventId = intval($_POST['event_id']);
  $lock = $pdo->prepare('SELECT capacity,current_registrations,event_status FROM events WHERE event_id=? FOR UPDATE');
  $lock->execute([$eventId]); $event = $lock->fetch(PDO::FETCH_ASSOC);
  if (!$event || $event['event_status']!='Active' || $event['current_registrations'] >= $event['capacity']) { throw new Exception('Event unavailable or full'); }
  $p=$pdo->prepare('INSERT INTO participants(participant_name,email,phone) VALUES(?,?,?)');
  $p->execute([$_POST['participant_name'],$_POST['email'],$_POST['phone']]);
  $pid=$pdo->lastInsertId();
  $r=$pdo->prepare('INSERT INTO registrations(event_id,participant_id) VALUES(?,?)'); $r->execute([$eventId,$pid]);
  $u=$pdo->prepare('UPDATE events SET current_registrations=current_registrations+1 WHERE event_id=?'); $u->execute([$eventId]);
  $pdo->commit(); echo json_encode(['success'=>true,'participant_id'=>$pid]);
} catch(Exception $e) { if($pdo->inTransaction()) $pdo->rollBack(); http_response_code(400); echo json_encode(['success'=>false,'message'=>$e->getMessage()]); }
?>
