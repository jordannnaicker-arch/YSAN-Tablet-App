<?php require 'db.php'; header('Content-Type: application/json');
$sql='SELECT r.registration_id,e.event_name,p.participant_name,p.email,p.phone,r.registration_timestamp FROM registrations r JOIN events e ON r.event_id=e.event_id JOIN participants p ON r.participant_id=p.participant_id ORDER BY r.registration_timestamp DESC';
echo json_encode($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC));
?>
