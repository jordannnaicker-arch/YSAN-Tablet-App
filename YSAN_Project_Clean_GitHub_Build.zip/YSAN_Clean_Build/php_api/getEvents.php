<?php require 'db.php'; header('Content-Type: application/json');
echo json_encode($pdo->query('SELECT * FROM events ORDER BY event_datetime')->fetchAll(PDO::FETCH_ASSOC));
?>
