<?php require 'db.php'; header('Content-Type: application/json');
$stmt=$pdo->prepare('INSERT INTO events(event_name,sports_category,event_datetime,venue,capacity,event_status,coordinator_name) VALUES(?,?,?,?,?,?,?)');
$stmt->execute([$_POST['event_name'],$_POST['sports_category'],$_POST['event_datetime'],$_POST['venue'],$_POST['capacity'],$_POST['event_status'],$_POST['coordinator_name']]);
echo json_encode(['success'=>true,'event_id'=>$pdo->lastInsertId()]);
?>
