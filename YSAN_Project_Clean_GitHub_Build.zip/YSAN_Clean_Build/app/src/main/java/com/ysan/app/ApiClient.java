package com.ysan.app;

import java.io.*;
import java.net.*;
import java.util.*;

public class ApiClient {
    public static String API_BASE = "http://10.0.2.2/ysan_api/";
    public static String post(String endpoint, Map<String,String> params) throws Exception {
        URL url = new URL(API_BASE + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST"); conn.setDoOutput(true); conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
        StringBuilder body = new StringBuilder();
        for (String k : params.keySet()) {
            if (body.length() > 0) body.append('&');
            body.append(URLEncoder.encode(k, "UTF-8")).append('=').append(URLEncoder.encode(params.get(k), "UTF-8"));
        }
        OutputStream os = conn.getOutputStream(); os.write(body.toString().getBytes("UTF-8")); os.close();
        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line; StringBuilder sb = new StringBuilder();
        while ((line = br.readLine()) != null) sb.append(line);
        br.close(); return sb.toString();
    }
}
