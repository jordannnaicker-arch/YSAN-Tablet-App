package com.ysan.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

public class LocalStore {
    private static final String PREF = "ysan_store";
    private static final String EVENTS = "events";
    private static final String REGS = "registrations";

    public static JSONArray getEvents(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            String data = p.getString(EVENTS, null);
            if (data == null) {
                JSONArray seed = new JSONArray();
                add(seed, 1, "Soccer Skills Clinic", "Soccer", "2026-06-20 09:00", "Durban Sports Field", 50, 18, "Active", "Mr Dlamini");
                add(seed, 2, "Athletics Sprint Workshop", "Athletics", "2026-06-22 10:00", "Kings Park Track", 40, 12, "Active", "Ms Naidoo");
                add(seed, 3, "Basketball Fundamentals", "Basketball", "2026-06-24 13:00", "Community Indoor Court", 30, 9, "Active", "Coach Mthembu");
                add(seed, 4, "Netball Training Day", "Netball", "2026-06-26 11:00", "Northwood Courts", 35, 15, "Active", "Ms Govender");
                add(seed, 5, "Fitness & Conditioning", "Fitness", "2026-06-28 08:30", "YSAN Fitness Hall", 60, 21, "Active", "Mr Pillay");
                saveEvents(c, seed);
                return seed;
            }
            return new JSONArray(data);
        } catch (Exception e) { return new JSONArray(); }
    }

    private static void add(JSONArray arr, int id, String name, String cat, String date, String venue, int capacity, int current, String status, String coord) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", id); o.put("name", name); o.put("category", cat); o.put("date", date); o.put("venue", venue);
        o.put("capacity", capacity); o.put("current", current); o.put("status", status); o.put("coordinator", coord);
        arr.put(o);
    }

    public static void saveEvents(Context c, JSONArray arr) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(EVENTS, arr.toString()).apply();
    }

    public static JSONArray getRegistrations(Context c) {
        try { return new JSONArray(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(REGS, "[]")); }
        catch(Exception e) { return new JSONArray(); }
    }

    public static void addRegistration(Context c, JSONObject reg) {
        try {
            JSONArray regs = getRegistrations(c); regs.put(reg);
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(REGS, regs.toString()).apply();
            JSONArray events = getEvents(c);
            int eventId = reg.getInt("eventId");
            for (int i=0;i<events.length();i++) {
                JSONObject ev = events.getJSONObject(i);
                if (ev.getInt("id") == eventId) { ev.put("current", ev.getInt("current") + 1); }
            }
            saveEvents(c, events);
        } catch(Exception ignored) {}
    }
}
