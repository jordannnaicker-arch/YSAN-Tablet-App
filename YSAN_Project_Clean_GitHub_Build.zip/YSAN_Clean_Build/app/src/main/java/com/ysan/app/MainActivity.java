package com.ysan.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.view.animation.*;import android.widget.*;import org.json.*;

public class MainActivity extends Activity{
 int green=Color.rgb(11,110,79);
 public void onCreate(Bundle b){super.onCreate(b); build();}
 TextView tv(String t,int sp,int style){TextView v=new TextView(this);v.setText(t);v.setTextSize(sp);v.setTextColor(Color.rgb(30,30,30));v.setPadding(12,8,12,8);v.setTypeface(null,style);return v;}
 Button btn(String t){Button b=new Button(this);b.setText(t);b.setTextColor(Color.WHITE);b.setBackgroundColor(green);b.setPadding(12,12,12,12);return b;}
 void build(){ScrollView sv=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);sv.addView(root);
  TextView title=tv("Youth Sports Advancement Network",26,1);root.addView(title);root.addView(tv("Tablet Event Overview Dashboard",18,0));
  LinearLayout nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);root.addView(nav);Button m=btn("Event Management");Button r=btn("Register Participant");nav.addView(m,new LinearLayout.LayoutParams(0,-2,1));nav.addView(r,new LinearLayout.LayoutParams(0,-2,1));
  m.setOnClickListener(v->startActivity(new Intent(this,ManagementActivity.class)));r.setOnClickListener(v->startActivity(new Intent(this,RegistrationActivity.class)));
  GridLayout grid=new GridLayout(this);grid.setColumnCount(2);grid.setPadding(0,20,0,0);root.addView(grid);
  JSONArray events=LocalStore.getEvents(this); try{for(int i=0;i<events.length();i++){JSONObject e=events.getJSONObject(i);TextView card=tv(e.getString("category")+"\n"+e.getString("name")+"\nDate: "+e.getString("date")+"\nVenue: "+e.getString("venue")+"\nRegistrations: "+e.getInt("current")+"/"+e.getInt("capacity")+"\nStatus: "+e.getString("status"),16,0);card.setBackgroundColor(Color.rgb(232,244,239));card.setPadding(20,20,20,20);GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=GridLayout.LayoutParams.WRAP_CONTENT;lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(10,10,10,10);grid.addView(card,lp);card.startAnimation(AnimationUtils.loadAnimation(this,R.anim.fade_in));}}catch(Exception ex){}
  setContentView(sv);
 }
 protected void onResume(){super.onResume();}
}
