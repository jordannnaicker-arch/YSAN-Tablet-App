package com.ysan.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.view.animation.*;import android.widget.*;import org.json.*;import java.text.*;import java.util.*;

public class RegistrationActivity extends Activity{Spinner sp;EditText name,email,phone;TextView history;JSONArray events;
 public void onCreate(Bundle b){super.onCreate(b);build();}
 void build(){ScrollView sv=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(26,26,26,26);sv.addView(root);TextView title=new TextView(this);title.setText("Participant Registration");title.setTextSize(26);root.addView(title);
  events=LocalStore.getEvents(this);sp=new Spinner(this);String[] names=new String[events.length()];try{for(int i=0;i<events.length();i++)names[i]=events.getJSONObject(i).getString("name");}catch(Exception e){}sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(sp);
  name=new EditText(this);name.setHint("Participant/Parent Name");root.addView(name);email=new EditText(this);email.setHint("Email Address");root.addView(email);phone=new EditText(this);phone.setHint("Phone Number");root.addView(phone);
  Button save=new Button(this);save.setText("Register Now");save.setTextColor(Color.WHITE);save.setBackgroundColor(Color.rgb(11,110,79));root.addView(save);history=new TextView(this);history.setTextSize(16);root.addView(history);
  save.setOnClickListener(v->register());showHistory();setContentView(sv);}
 void register(){try{JSONObject ev=events.getJSONObject(sp.getSelectedItemPosition());JSONObject reg=new JSONObject();reg.put("eventId",ev.getInt("id"));reg.put("event",ev.getString("name"));reg.put("name",name.getText().toString());reg.put("email",email.getText().toString());reg.put("phone",phone.getText().toString());reg.put("timestamp",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date()));LocalStore.addRegistration(this,reg);Toast.makeText(this,"Registration saved with timestamp",Toast.LENGTH_LONG).show();history.startAnimation(AnimationUtils.loadAnimation(this,R.anim.scale_success));showHistory();}catch(Exception e){Toast.makeText(this,"Could not register",Toast.LENGTH_LONG).show();}}
 void showHistory(){try{JSONArray regs=LocalStore.getRegistrations(this);StringBuilder sb=new StringBuilder("\nPrevious Registrations\n");for(int i=0;i<regs.length();i++){JSONObject r=regs.getJSONObject(i);sb.append("• ").append(r.getString("name")).append(" - ").append(r.getString("event")).append(" @ ").append(r.getString("timestamp")).append("\n");}history.setText(sb.toString());}catch(Exception e){}}
}
