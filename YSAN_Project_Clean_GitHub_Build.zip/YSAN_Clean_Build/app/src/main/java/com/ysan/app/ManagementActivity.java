package com.ysan.app;

import android.app.*;import android.os.*;import android.graphics.Color;import android.widget.*;import org.json.*;

public class ManagementActivity extends Activity{EditText n,cat,date,venue,cap,coord;Spinner status;TextView list;
 public void onCreate(Bundle b){super.onCreate(b);build();}
 void build(){ScrollView sv=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(26,26,26,26);sv.addView(root);TextView t=new TextView(this);t.setText("Event Management");t.setTextSize(26);root.addView(t);
  n=e("Event Name");cat=e("Category: Soccer/Athletics/Basketball/Netball/Fitness");date=e("Event Date & Time");venue=e("Venue");cap=e("Capacity");coord=e("Coordinator Name");root.addView(n);root.addView(cat);root.addView(date);root.addView(venue);root.addView(cap);root.addView(coord);
  status=new Spinner(this);status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Active","Full","Cancelled","Completed"}));root.addView(status);Button save=new Button(this);save.setText("Create Event");save.setTextColor(Color.WHITE);save.setBackgroundColor(Color.rgb(11,110,79));root.addView(save);list=new TextView(this);list.setTextSize(16);root.addView(list);save.setOnClickListener(v->saveEvent());showEvents();setContentView(sv);}
 EditText e(String h){EditText x=new EditText(this);x.setHint(h);return x;}
 void saveEvent(){try{JSONArray arr=LocalStore.getEvents(this);JSONObject o=new JSONObject();o.put("id",arr.length()+1);o.put("name",n.getText().toString());o.put("category",cat.getText().toString());o.put("date",date.getText().toString());o.put("venue",venue.getText().toString());o.put("capacity",Integer.parseInt(cap.getText().toString()));o.put("current",0);o.put("status",status.getSelectedItem().toString());o.put("coordinator",coord.getText().toString());arr.put(o);LocalStore.saveEvents(this,arr);Toast.makeText(this,"Event saved and persisted",Toast.LENGTH_LONG).show();showEvents();}catch(Exception e){Toast.makeText(this,"Check all event fields",Toast.LENGTH_LONG).show();}}
 void showEvents(){try{JSONArray arr=LocalStore.getEvents(this);StringBuilder sb=new StringBuilder("\nCurrent Events\n");for(int i=0;i<arr.length();i++){JSONObject e=arr.getJSONObject(i);sb.append("• ").append(e.getString("name")).append(" | ").append(e.getString("status")).append(" | ").append(e.getInt("current")).append("/").append(e.getInt("capacity")).append("\n");}list.setText(sb.toString());}catch(Exception e){}}
}
