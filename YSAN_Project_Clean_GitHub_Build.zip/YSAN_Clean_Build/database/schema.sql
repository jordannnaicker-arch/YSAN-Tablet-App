CREATE DATABASE IF NOT EXISTS ysan_db;
USE ysan_db;

CREATE TABLE events (
  event_id INT AUTO_INCREMENT PRIMARY KEY,
  event_name VARCHAR(120) NOT NULL,
  sports_category ENUM('Soccer','Athletics','Basketball','Netball','Fitness') NOT NULL,
  event_datetime DATETIME NOT NULL,
  venue VARCHAR(120) NOT NULL,
  capacity INT NOT NULL CHECK (capacity > 0),
  current_registrations INT NOT NULL DEFAULT 0,
  event_status ENUM('Active','Full','Cancelled','Completed') NOT NULL DEFAULT 'Active',
  coordinator_name VARCHAR(100) NOT NULL
);

CREATE TABLE participants (
  participant_id INT AUTO_INCREMENT PRIMARY KEY,
  participant_name VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL
);

CREATE TABLE registrations (
  registration_id INT AUTO_INCREMENT PRIMARY KEY,
  event_id INT NOT NULL,
  participant_id INT NOT NULL,
  registration_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (event_id) REFERENCES events(event_id),
  FOREIGN KEY (participant_id) REFERENCES participants(participant_id)
);

INSERT INTO events(event_name,sports_category,event_datetime,venue,capacity,current_registrations,event_status,coordinator_name) VALUES
('Soccer Skills Clinic','Soccer','2026-06-20 09:00:00','Durban Sports Field',50,18,'Active','Mr Dlamini'),
('Athletics Sprint Workshop','Athletics','2026-06-22 10:00:00','Kings Park Track',40,12,'Active','Ms Naidoo'),
('Basketball Fundamentals','Basketball','2026-06-24 13:00:00','Community Indoor Court',30,9,'Active','Coach Mthembu'),
('Netball Training Day','Netball','2026-06-26 11:00:00','Northwood Courts',35,15,'Active','Ms Govender'),
('Fitness & Conditioning','Fitness','2026-06-28 08:30:00','YSAN Fitness Hall',60,21,'Active','Mr Pillay');
