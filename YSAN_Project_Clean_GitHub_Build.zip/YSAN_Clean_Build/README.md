# YSAN Tablet App

This is a clean Android project for the Youth Sports Advancement Network assignment.

## How to build APK online
1. Extract this ZIP.
2. Upload the CONTENTS of the extracted folder to GitHub. Do not upload the ZIP as one file.
3. Go to GitHub > Actions > Android APK Build.
4. Click Run workflow.
5. Download the APK artifact named `YSAN-debug-apk`.

## Project contents
- `app/` Android source code
- `.github/workflows/android-build.yml` cloud APK builder
- `database/schema.sql` MySQL schema and sample data
- `php_api/` PHP backend endpoints
- `documentation/` assignment documentation
